<?php
$movie = $_GET['movie'] ?? 'Jawan';
$mobile = $_GET['mobile'] ?? 'Unknown';
$time = $_GET['time'] ?? 'Unknown';
$seats = $_GET['seats'] ?? 'None';
$amount = $_GET['amount'] ?? '0';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Your Ticket | Night Vision Cinema</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <img src="assets/logo.png" class="logo">
    <h1>Night Vision Cinema</h1>
  </header>

  <div class="ticket">
    <h2>🎟 Ticket Confirmation</h2>
    <p><strong>Movie:</strong> <?= $movie ?></p>
    <p><strong>Mobile:</strong> <?= $mobile ?></p>
    <p><strong>Time:</strong> <?= $time ?></p>
    <p><strong>Seats:</strong> <?= $seats ?></p>
    <p><strong>Amount Paid:</strong> ₹<?= $amount ?></p>
    <p>✅ Show this at the entrance.</p>
  </div>
</body>
</html>