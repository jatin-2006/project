const url = new URL(window.location.href);
const movie = url.searchParams.get("movie");
const mobile = url.searchParams.get("mobile");
const time = url.searchParams.get("time");

document.getElementById("movie").innerText = movie;
document.getElementById("mobile").innerText = mobile;
document.getElementById("time").innerText = time;

const container = document.getElementById("seats-container");
let selectedSeats = [];

for (let i = 1; i <= 70; i++) {
  let seat = document.createElement("div");
  seat.classList.add("seat");

  let label = i <= 9 ? `A0${i}` :
              i <= 19 ? `A${i}` :
              i <= 29 ? `B${i-19}` :
              i <= 39 ? `C${i-29}` :
              i <= 49 ? `D${i-39}` :
              i <= 59 ? `E${i-49}` :
              `F${i-59}`;

  seat.innerText = label;

  if (i <= 20) seat.classList.add("silver");
  else if (i <= 50) seat.classList.add("gold");
  else seat.classList.add("platinum");

  seat.onclick = () => {
    if (selectedSeats.includes(label)) {
      selectedSeats = selectedSeats.filter(s => s !== label);
      seat.classList.remove("selected");
    } else {
      if (selectedSeats.length >= 5) return alert("Max 5 seats allowed");
      selectedSeats.push(label);
      seat.classList.add("selected");
    }
    document.getElementById("selected").innerText = selectedSeats.join(", ") || "None";

    let total = 0;
    selectedSeats.forEach(s => {
      let num = parseInt(s.match(/\d+/)[0]);
      if (num <= 20) total += 100;
      else if (num <= 50) total += 150;
      else total += 200;
    });

    document.getElementById("amount").innerText = total;
  };

  container.appendChild(seat);
}

document.getElementById("proceed").onclick = () => {
  if (selectedSeats.length === 0) return alert("Please select seats");
  const amount = document.getElementById("amount").innerText;
  window.location.href = `payment.html?movie=${movie}&mobile=${mobile}&time=${time}&seats=${selectedSeats.join(",")}&amount=${amount}`;
};